
  var RpcClient = require('cryptodezirecashd-rpc');

  var config = {
    protocol: 'http',
    user: 'yanger',
    pass: 'aDsd371waDsd371waDsd371waDsd371w',
    host: '108.61.156.6',
    port: '35602',
  };

  var rpc = new RpcClient(config);

  var txids = [];
  console.log("Im running");

  function showNewTransactions() {
    rpc.getRawMemPool(function (err, ret) {
      if (err) {
        console.error(err);
        return setTimeout(showNewTransactions, 10000);
      }

      console.log("Im running");


      function batchCall() {
        ret.result.forEach(function (txid) {
          if (txids.indexOf(txid) === -1) {
            rpc.getRawTransaction(txid);
          }
        });
      }

      console.log("Im running");


      rpc.batch(batchCall, function(err, rawtxs) {
        if (err) {
          console.error(err);
          return setTimeout(showNewTransactions, 10000);
        }

        console.log("Im running");


        rawtxs.map(function (rawtx) {
          console.log('\n\n\n' + rawtx.result);
        });

        console.log('Im running');

        txids = ret.result;
        setTimeout(showNewTransactions, 2500);
      });
    });
  }

showNewTransactions();
